from pathlib import Path
from pmeval import evaluate, list_metrics


def test_metrics_registered():
    assert "prd_quality" in list_metrics()
    assert "eval_plan" in list_metrics()


def test_prd_quality_runs():
    text = Path("examples/sample_prd.md").read_text(encoding="utf-8")
    result = evaluate("prd_quality", text)
    assert result.overall_score > 50
    assert result.metric == "prd_quality"
    assert result.dimension_scores


def test_json_output_parses():
    import json
    text = Path("examples/sample_eval_plan.md").read_text(encoding="utf-8")
    result = evaluate("eval_plan", text)
    parsed = json.loads(result.to_json())
    assert parsed["metric"] == "eval_plan"
    assert "overall_score" in parsed
